-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2022 at 05:10 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zugoshi`
--

-- --------------------------------------------------------

--
-- Table structure for table `collections`
--

CREATE TABLE `collections` (
  `id` int(7) NOT NULL,
  `barang` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `harga` int(12) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `collections`
--

INSERT INTO `collections` (`id`, `barang`, `kategori`, `harga`, `gambar`) VALUES
(3, '35 Mechatro Wego Kumi Tateshiki 2 1/35 Scale Model Kit', 'Action Figure', 559900, 'assets/ActionFigures/Gambar1.jpg'),
(4, 'ROBOT SPIRITS X KA SIGNATURE FULL ARMOR GUNDAM MK-II', 'Action Models', 2499900, 'assets/ActionModels/Gambar1.jpg'),
(5, 'MACROSS VF-1J VALKYRIE MAX & MIRIYA 1/72 SCALE GIFTSET', 'Action Models', 3559900, 'assets/ActionModels/Gambar3.jpg'),
(6, 'LEGO FRIENDS 30416 MARKET STALL POLYBAG FRIEND MIA LIZ MINI', 'Lego', 559900, 'assets/Lego/Gambar1.jpg'),
(7, 'LEGO 40483 STAR WARS LUKE SKYWALKER\'S LIGHTSABER', 'Lego', 3499900, 'assets/Lego/Gambar2.jpg'),
(8, 'STAR WARS EPISODE 1:OOM-9 WITH BLASTER AND BINOCULARS', 'Action Figures', 200000, 'assets/ActionFigures/Gambar2.jpg'),
(11, 'Lego Olaf', 'lego', 2000000, 'assets/ActionFigures/1.Mechatro Wego Kumi Tateshiki.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(7) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `phone`, `username`, `password`, `email`) VALUES
(9, 'Almanda Karenina', '0855694192479', 'mandakarenina', 'mandakarenina150', 'mandakarenina150@gmail.com'),
(11, 'bila', '087777799999', 'bilaaa', 'asdfghjkl123', 'bila@gmail.com'),
(15, 'niall horan', '08755555999', 'nialler', 'asdfgfg', 'niallerhoran@gmail.com'),
(16, 'niall horan', '08755555999', 'nialler', 'asdfghjkl12345', 'niallerhoran@gmail.com'),
(17, 'Kelompok6', '081265478974', 'Kelompok6', 'kelompok6', 'Kelompok6@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `collections`
--
ALTER TABLE `collections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `collections`
--
ALTER TABLE `collections`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
